require("dotenv").config();

module.exports = {
  SECRET: process.env.SECRET,
};